# 💈 James’s Saloon – Welcome Design

**Brand Message:**  
Most welcome to James’s Saloon – Your look, your value.

**Project Type:** Personal/Branding Poster  
**Client:** James’s Saloon  
**Tools Used:** Photoshop, Canva  
**Design Goal:** To welcome clients and reinforce trust and identity through a professional look and feel.

## Highlights:
- Classy grooming salon theme
- Personal slogan for brand connection
- Soft lighting and neat composition

---

**Designed by [kjamesgraphics](https://github.com/kjamesgraphics)**
