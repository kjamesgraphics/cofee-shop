# 🚫 No Excuse for Abuse – GBV Awareness Banner

**Campaign Message:**  
No Excuse for Abuse – Let’s stand against gender-based violence in our families and society.

**Project Type:** Social Advocacy  
**Client:** Navigating Motherhood Together  
**Tools Used:** Photoshop, Canva  
**Design Goal:** To raise awareness of GBV and promote peaceful, respectful homes and communities.

## Highlights:
- Powerful slogan and call to action
- Warm but urgent color palette
- Inclusive visuals and bold typography

---

**Designed by [kjamesgraphics](https://github.com/kjamesgraphics)**
