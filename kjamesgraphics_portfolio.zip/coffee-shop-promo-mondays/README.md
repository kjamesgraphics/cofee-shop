# ☕ Flying West Coffee – Monday Promotion

**Promo Message:**  
Every Monday it's promotion time at Flying West Coffee Shop! Enjoy special prices and fresh brews.

**Project Type:** Business Advertisement  
**Client:** Flying West Coffee Shop  
**Tools Used:** Canva  
**Design Goal:** To promote weekly specials and increase customer visits on slow days.

## Highlights:
- Bright, inviting coffee imagery
- Promo day callout (Mondays)
- Brand alignment with warm tones

---

**Designed by [kjamesgraphics](https://github.com/kjamesgraphics)**
